with motd
